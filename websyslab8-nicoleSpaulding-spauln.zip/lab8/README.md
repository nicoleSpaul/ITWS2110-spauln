For this lab I assumed question 8 meant order by all categories alphabetically, not order by each individually and output 4 tables. I thought this lab was a good test to make sure I had things set up correctly using XAMPP, and whether I could use it successfully which I'm grateful for as we approach the dealine for our final projects.

---

NOTE: 

commands.txt is a copy of the SQL commands + which part they are for, to see a better formatted version please see the Lab8Database&Commands.docx to see BOTH the text of structure/content of database AND the commands/output section.


GitHub Link:
https://github.com/nicoleSpaul/ITWS2110-spauln/tree/main/lab8